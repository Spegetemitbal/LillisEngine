#include <Lillis.h>

int main(int argc, char* argv[])
{
	Engine* e;

	if (argc > 1)
	{
		e = Engine::CreateGameInstance(true);
		std::cout << "Launching as Server\n";
	}
	else
	{
		e = Engine::CreateGameInstance(false);
		std::cout << "Launching as Client\n";
	}
	
	//e->LoadLevel("Level.dat");
	e->Run();

	Engine::DestroyGameInstance();

	return 0;
}
